-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 04 juin 2021 à 23:52
-- Version du serveur :  10.4.19-MariaDB
-- Version de PHP : 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `election`
--

-- --------------------------------------------------------

--
-- Structure de la table `electeur`
--

CREATE TABLE `electeur` (
  `idElecteur` int(11) NOT NULL,
  `pseudo` varchar(20) NOT NULL,
  `motPass` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `dateInscription` date DEFAULT NULL,
  `idPartiElu` int(11) DEFAULT NULL,
  `idGouvernorat` int(11) NOT NULL,
  `dateDerniereElection` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `electeur`
--

INSERT INTO `electeur` (`idElecteur`, `pseudo`, `motPass`, `age`, `dateInscription`, `idPartiElu`, `idGouvernorat`, `dateDerniereElection`) VALUES
(1, 'ayoub', 'ayoub123', 20, '2021-06-04', 5, 24, '2021-06-04 21:28:54'),
(2, 'mehrez', 'mehrez123', 55, '2021-06-04', 1, 24, '2021-06-04 21:30:18'),
(3, 'najwa', 'benothmen', 50, '2021-06-04', 7, 1, '2021-06-04 21:31:30');

-- --------------------------------------------------------

--
-- Structure de la table `gouvernorat`
--

CREATE TABLE `gouvernorat` (
  `idGouvernorat` int(10) NOT NULL,
  `nomGouvernorat` varchar(50) NOT NULL,
  `nombreSieges` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `gouvernorat`
--

INSERT INTO `gouvernorat` (`idGouvernorat`, `nomGouvernorat`, `nombreSieges`) VALUES
(1, 'Tunis', 15),
(2, 'Ariana', 12),
(3, 'Manouba', 10),
(4, 'Ben Arous', 9),
(5, 'Nabeul', 7),
(6, 'Sousse', 13),
(7, 'Monastir', 8),
(8, 'Mahdia', 8),
(9, 'Sfax', 14),
(10, 'Gabes', 10),
(11, 'Mednine', 9),
(12, 'Tataouine', 7),
(13, 'Gafsa', 7),
(14, 'Tozeur', 8),
(15, 'Kebili', 8),
(16, 'Kairouan', 6),
(17, 'Tela', 10),
(18, 'Siliana', 9),
(19, 'Kef', 7),
(20, 'Jendouba', 7),
(21, 'Beja', 8),
(22, 'Kasserine', 8),
(23, 'Bizerte', 6),
(24, 'Zagouan', 10);

-- --------------------------------------------------------

--
-- Structure de la table `partipolitique`
--

CREATE TABLE `partipolitique` (
  `idParti` int(11) NOT NULL,
  `nomParti` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `partipolitique`
--

INSERT INTO `partipolitique` (`idParti`, `nomParti`) VALUES
(1, 'Annahdha'),
(2, 'Ettaillar'),
(3, 'PDL'),
(4, 'Front Populaire'),
(5, 'Ajjomhouri'),
(6, 'PDM'),
(7, 'Afek Tunis');

-- --------------------------------------------------------

--
-- Structure de la table `voix`
--

CREATE TABLE `voix` (
  `idVoix` int(11) NOT NULL,
  `idGouvernorat` int(11) NOT NULL,
  `idParti` int(11) NOT NULL,
  `nombreVoix` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `voix`
--

INSERT INTO `voix` (`idVoix`, `idGouvernorat`, `idParti`, `nombreVoix`) VALUES
(168, 1, 1, 7246),
(169, 1, 2, 6917),
(170, 1, 3, 3170),
(171, 1, 4, 2307),
(172, 1, 5, 9634),
(173, 1, 6, 9126),
(174, 1, 7, 3187),
(175, 2, 1, 757),
(176, 2, 2, 4742),
(177, 2, 3, 2249),
(178, 2, 4, 8777),
(179, 2, 5, 8082),
(180, 2, 6, 9360),
(181, 2, 7, 1600),
(182, 3, 1, 9280),
(183, 3, 2, 3572),
(184, 3, 3, 5264),
(185, 3, 4, 3538),
(186, 3, 5, 8163),
(187, 3, 6, 9312),
(188, 3, 7, 3365),
(189, 4, 1, 1565),
(190, 4, 2, 8278),
(191, 4, 3, 4432),
(192, 4, 4, 8932),
(193, 4, 5, 3696),
(194, 4, 6, 7242),
(195, 4, 7, 5905),
(196, 5, 1, 9180),
(197, 5, 2, 2084),
(198, 5, 3, 1248),
(199, 5, 4, 2657),
(200, 5, 5, 4006),
(201, 5, 6, 6937),
(202, 5, 7, 7794),
(203, 6, 1, 6537),
(204, 6, 2, 7994),
(205, 6, 3, 2597),
(206, 6, 4, 7351),
(207, 6, 5, 4500),
(208, 6, 6, 7060),
(209, 6, 7, 8822),
(210, 7, 1, 3800),
(211, 7, 2, 3031),
(212, 7, 3, 6773),
(213, 7, 4, 5905),
(214, 7, 5, 2523),
(215, 7, 6, 2827),
(216, 7, 7, 3246),
(217, 8, 1, 6593),
(218, 8, 2, 5211),
(219, 8, 3, 1205),
(220, 8, 4, 3341),
(221, 8, 5, 3302),
(222, 8, 6, 7346),
(223, 8, 7, 1097),
(224, 9, 1, 4819),
(225, 9, 2, 6813),
(226, 9, 3, 5577),
(227, 9, 4, 9978),
(228, 9, 5, 1961),
(229, 9, 6, 3395),
(230, 9, 7, 6126),
(231, 10, 1, 5457),
(232, 10, 2, 7361),
(233, 10, 3, 2361),
(234, 10, 4, 6532),
(235, 10, 5, 5452),
(236, 10, 6, 9637),
(237, 10, 7, 870),
(238, 11, 1, 7055),
(239, 11, 2, 3065),
(240, 11, 3, 6047),
(241, 11, 4, 5701),
(242, 11, 5, 3681),
(243, 11, 6, 1312),
(244, 11, 7, 1916),
(245, 12, 1, 6845),
(246, 12, 2, 9910),
(247, 12, 3, 7787),
(248, 12, 4, 4564),
(249, 12, 5, 3475),
(250, 12, 6, 2633),
(251, 12, 7, 2207),
(252, 13, 1, 1526),
(253, 13, 2, 2801),
(254, 13, 3, 7704),
(255, 13, 4, 7896),
(256, 13, 5, 8799),
(257, 13, 6, 5571),
(258, 13, 7, 9079),
(259, 14, 1, 9863),
(260, 14, 2, 7071),
(261, 14, 3, 9320),
(262, 14, 4, 6870),
(263, 14, 5, 7248),
(264, 14, 6, 5257),
(265, 14, 7, 7458),
(266, 15, 1, 7868),
(267, 15, 2, 1944),
(268, 15, 3, 8614),
(269, 15, 4, 4546),
(270, 15, 5, 7578),
(271, 15, 6, 3134),
(272, 15, 7, 8980),
(273, 16, 1, 7812),
(274, 16, 2, 8052),
(275, 16, 3, 2845),
(276, 16, 4, 5138),
(277, 16, 5, 877),
(278, 16, 6, 5241),
(279, 16, 7, 4638),
(280, 17, 1, 3096),
(281, 17, 2, 1788),
(282, 17, 3, 3723),
(283, 17, 4, 9061),
(284, 17, 5, 5046),
(285, 17, 6, 7218),
(286, 17, 7, 9702),
(287, 18, 1, 2688),
(288, 18, 2, 9132),
(289, 18, 3, 5886),
(290, 18, 4, 5378),
(291, 18, 5, 2224),
(292, 18, 6, 6103),
(293, 18, 7, 2034),
(294, 19, 1, 1611),
(295, 19, 2, 4632),
(296, 19, 3, 3033),
(297, 19, 4, 1239),
(298, 19, 5, 5523),
(299, 19, 6, 8090),
(300, 19, 7, 8446),
(301, 20, 1, 3256),
(302, 20, 2, 1825),
(303, 20, 3, 6203),
(304, 20, 4, 5299),
(305, 20, 5, 669),
(306, 20, 6, 1731),
(307, 20, 7, 563),
(308, 21, 1, 547),
(309, 21, 2, 2434),
(310, 21, 3, 861),
(311, 21, 4, 8886),
(312, 21, 5, 9488),
(313, 21, 6, 3972),
(314, 21, 7, 3312),
(315, 22, 1, 8009),
(316, 22, 2, 9023),
(317, 22, 3, 4512),
(318, 22, 4, 6165),
(319, 22, 5, 3031),
(320, 22, 6, 8632),
(321, 22, 7, 4878),
(322, 23, 1, 6942),
(323, 23, 2, 7794),
(324, 23, 3, 7480),
(325, 23, 4, 526),
(326, 23, 5, 1800),
(327, 23, 6, 9124),
(328, 23, 7, 9479),
(329, 24, 1, 2287),
(330, 24, 2, 2799),
(331, 24, 3, 4218),
(332, 24, 4, 7655),
(333, 24, 5, 5955),
(334, 24, 6, 1895),
(335, 24, 7, 9970);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `electeur`
--
ALTER TABLE `electeur`
  ADD PRIMARY KEY (`idElecteur`);

--
-- Index pour la table `gouvernorat`
--
ALTER TABLE `gouvernorat`
  ADD PRIMARY KEY (`idGouvernorat`);

--
-- Index pour la table `partipolitique`
--
ALTER TABLE `partipolitique`
  ADD PRIMARY KEY (`idParti`);

--
-- Index pour la table `voix`
--
ALTER TABLE `voix`
  ADD PRIMARY KEY (`idVoix`) USING BTREE;

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `electeur`
--
ALTER TABLE `electeur`
  MODIFY `idElecteur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `gouvernorat`
--
ALTER TABLE `gouvernorat`
  MODIFY `idGouvernorat` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT pour la table `partipolitique`
--
ALTER TABLE `partipolitique`
  MODIFY `idParti` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `voix`
--
ALTER TABLE `voix`
  MODIFY `idVoix` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=336;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
